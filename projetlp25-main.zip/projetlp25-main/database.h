
#ifndef _DATABASE_H
#define _DATABASE_H

void create_db_directory(char *name, char *path);
void recursive_rmdir(char *dirname);

